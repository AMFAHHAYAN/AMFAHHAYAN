from django.shortcuts import render,redirect
from django.views import View

# Create your views here.

class LandingPage(View):
    def get(self, request):
        return render (request, 'index.html')
    def post(self,request):
        return redirect("/")
    
class UserPage(View):
    def get(self, request):
        return render(request ,'user.html' )
    
class Login(View):
    def get(self, request):
        return render(request, 'login.html')

class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')
    
class Forget(View):
    def get(self, request):
        return render(request, 'forget.html')
    
class Dashboard(View):
    def get(self, request):
        return render(request, 'dashboard.html')

class Detail(View):
    def get(self, request):
        return render(request, 'detailproduct.html')