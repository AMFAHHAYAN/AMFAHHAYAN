from django.urls import path
from .views import *

urlpatterns = [
    path('', LandingPage.as_view(),name="index"),
    path('users/', UserPage.as_view(),name="Dashboard"),    
    path('login/', Login.as_view(),name="login"), 
    path('signup/', Signup.as_view(),name="signup")
]
