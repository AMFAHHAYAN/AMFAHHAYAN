import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Sidebar from "../admin/Sidebar";

const AdminPrivateLayout = ({ children }) => {
  const navigate = useNavigate();
  const { token, role } = useSelector((state) => state.loggedInData);

  useEffect(() => {
    if (!token || role !== "admin") {
      navigate("/");
    }
  }, [token, role, navigate]);

  return (
    <div className="flex h-screen">
      <Sidebar className="w-64 bg-gray-800 text-white p-4" />
      <div className="flex-1 p-4 bg-gray-100 overflow-y-auto">
        {children}
      </div>
    </div>
  );
};

export default AdminPrivateLayout;
