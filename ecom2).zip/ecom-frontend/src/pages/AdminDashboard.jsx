import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import CountUp from "react-countup";

const AdminPanel = () => {
  const [totalProducts, setTotalProducts] = useState(0);
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalOrders, setTotalOrders] = useState(0);

  useEffect(() => {
    setTimeout(() => {
      setTotalProducts(150); // Example data
      setTotalUsers(300); // Example data
      setTotalOrders(120); // Example data
    }, 1000);
  }, []);

  return (
    <div className="admin-panel p-10 min-h-screen bg-gradient-to-r from-indigo-50 via-indigo-100 to-indigo-200 flex flex-col items-center relative">
      {/* Panel Title */}
      <h1 className="text-4xl md:text-6xl font-extrabold mb-12 text-center text-indigo-700 tracking-wide">
        Admin Panel
      </h1>
    </div>
  );
  //     {/* Statistic Cards Section */}
  //     <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 max-w-screen-xl">
  //       {/* Total Products Card */}
  //       <motion.div
  //         className="stat-card bg-white p-8 rounded-lg shadow-lg text-gray-800 flex flex-col items-center transform hover:scale-105 hover:shadow-2xl transition-all duration-300"
  //         whileHover={{ scale: 1.05 }}
  //       >
  //         <div className="mb-4">
  //           <i className="fas fa-box fa-4x text-indigo-600"></i>
  //         </div>
  //         <h2 className="text-2xl sm:text-3xl font-semibold text-indigo-600">
  //           Total Products
  //         </h2>
  //         <p className="text-4xl sm:text-6xl font-extrabold mt-3 text-gray-900">
  //           <CountUp end={totalProducts} duration={3} />
  //         </p>
  //       </motion.div>

  //       {/* Total Users Card */}
  //       <motion.div
  //         className="stat-card bg-white p-8 rounded-lg shadow-lg text-gray-800 flex flex-col items-center transform hover:scale-105 hover:shadow-2xl transition-all duration-300"
  //         whileHover={{ scale: 1.05 }}
  //       >
  //         <div className="mb-4">
  //           <i className="fas fa-users fa-4x text-teal-600"></i>
  //         </div>
  //         <h2 className="text-2xl sm:text-3xl font-semibold text-teal-600">
  //           Total Users
  //         </h2>
  //         <p className="text-4xl sm:text-6xl font-extrabold mt-3 text-gray-900">
  //           <CountUp end={totalUsers} duration={3} />
  //         </p>
  //       </motion.div>

  //       {/* Total Orders Card */}
  //       <motion.div
  //         className="stat-card bg-white p-8 rounded-lg shadow-lg text-gray-800 flex flex-col items-center transform hover:scale-105 hover:shadow-2xl transition-all duration-300"
  //         whileHover={{ scale: 1.05 }}
  //       >
  //         <div className="mb-4">
  //           <i className="fas fa-shopping-cart fa-4x text-yellow-600"></i>
  //         </div>
  //         <h2 className="text-2xl sm:text-3xl font-semibold text-yellow-600">
  //           Total Orders
  //         </h2>
  //         <p className="text-4xl sm:text-6xl font-extrabold mt-3 text-gray-900">
  //           <CountUp end={totalOrders} duration={3} />
  //         </p>
  //       </motion.div>
  //     </div>
  //   </div>
  // );
};

export default AdminPanel;
