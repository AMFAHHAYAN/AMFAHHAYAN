import express from "express";
import cors from "cors";
import { startConnection } from "./config/dbConnection";

const app = express();

startConnection();

app.use(express.json())
app.use(cors({origin:"*"}))

import adminRoutes from "./route/admin.r"
import userRoutes from "./route/user.r"

app.use("/",userRoutes)
app.use("/admin",adminRoutes)
app.use("/image",express.static("images"))

export default app;