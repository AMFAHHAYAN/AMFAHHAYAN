// navbar.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  // Dynamic username - this could be retrieved from a user service or authentication service
  username: string = 'John Doe';

  logout() {
    // Logic for logging out
    console.log('Logging out...');
  }

  viewAppointments() {
    // Logic for viewing appointments
    console.log('Navigating to My Appointments...');
  }
}
