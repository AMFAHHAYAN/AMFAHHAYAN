import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // Import HttpClient
import { Observable } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  doctors: any[] = [];
  loading: boolean = true;
  error: string | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Make the API request
    this.getDoctors().subscribe(
      (data) => {
        this.doctors = data;
        this.loading = false;
      },
      (error) => {
        this.error = 'Failed to load doctor data';
        this.loading = false;
      }
    );
  }
  
  getDoctors(): Observable<any[]> {
    const headers = new HttpHeaders().set('Authorization', 'Token YOUR_AUTH_TOKEN_HERE'); // Replace with actual token
    return this.http.get<any[]>('http://127.0.0.1:8000/doctor-list/', { headers });
  }
}
