import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private registerUrl = 'http://127.0.0.1:8000/register/';  // URL to the backend API for registration
  private loginUrl = 'http://127.0.0.1:8000/login/';      // URL to the backend API for login
  private dashboardUrl = 'http://127.0.0.1:8000/doctor-list/';
  constructor(private http: HttpClient) {}

  // Method to register a user
  registerUser(userData: any): Observable<any> {
    return this.http.post<any>(this.registerUrl, userData).pipe(
      catchError(this.handleError)  // Handle errors if any
    );
  }

  // Method to log in a user
  loginUser(credentials: any): Observable<any> {
    return this.http.post<any>(this.loginUrl, credentials).pipe(
      catchError(this.handleError)  // Handle errors if any
    );
  }

  // Method to handle HTTP errors
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    throw error;
  }

  // Save both the access and refresh tokens to localStorage
  saveTokens(accessToken: string, refreshToken: string): void {
    localStorage.setItem('access_token', accessToken);
    localStorage.setItem('refresh_token', refreshToken);
  }

  // Get the access token from localStorage
  getAccessToken(): string | null {
    return localStorage.getItem('access_token');
  }

  // Get the refresh token from localStorage
  getRefreshToken(): string | null {
    return localStorage.getItem('refresh_token');
  }

  // Remove both tokens from localStorage (e.g., when logging out)
  removeTokens(): void {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
  }
  
}
