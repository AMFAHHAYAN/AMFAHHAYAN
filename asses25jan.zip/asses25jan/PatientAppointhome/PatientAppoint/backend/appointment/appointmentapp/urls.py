from django.urls import path
from .views import *

urlpatterns = [
    # User routes
    path('register/',RegisterView.as_view(), name='register'),
    path('login/',LoginView.as_view(), name='login'),
    path('logout/',LogoutView.as_view(), name='logout'),
    path('update/', UserRetrieveUpdateDestroyView.as_view(), name='user-update'),
    
    # Doctor routes
    path('doctors/', DoctorListCreateView.as_view(), name='doctor-list-create'),
    path('doctor/login/', DoctorLoginView.as_view(), name='doctor-login'),
    path('doctors/<int:pk>/', DoctorRetrieveUpdateDestroyView.as_view(), name='doctor-retrieve-update-destroy'),
    path('doctor-list/', DoctorListView.as_view(), name='doctor-list'),
    
    # Appointment routes
    path('appointments/', AppointmentListCreateView.as_view(), name='appointment-list-create'),
    path('appointments/<int:pk>/', AppointmentRetrieveUpdateDestroyView.as_view(), name='appointment-retrieve-update-destroy'),
]
