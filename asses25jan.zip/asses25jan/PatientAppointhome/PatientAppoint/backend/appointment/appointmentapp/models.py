from django.db import models
from django.conf import settings
from django.core.mail import send_mail
from django.contrib.auth.hashers import make_password

class User(models.Model):
    fullname = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    email = models.EmailField()
    phone = models.CharField(max_length=10)
    password = models.CharField(max_length=100)
    address = models.TextField()
    
class Doctor(models.Model):
    image = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=100)
    specialization = models.CharField(max_length=50)
    location = models.TextField()
    availability = models.JSONField()
    email = models.EmailField()
    password = models.CharField(max_length=100) 
    
    def save(self, *args, **kwargs):
        if not self.pk: # Sends emails before password hashing
            send_doctor_credentials_email(self)
        
        self.password = make_password(self.password) # hash pass after sending mail
        super().save(*args, **kwargs)


def send_doctor_credentials_email(doctor):
    subject = 'HEY DOC Your credentials'
    message = f'Hey Doc, this is your login credentials for the Doctor Panel:\n\n' \
              f'URL: http://127.0.0.1:8000/doctor/login\n' \
              f'Email: {doctor.email}\n' \
              f'Password: {doctor.password}\n' \
              f'Please login and change your password after the first login.'
    from_email = settings.EMAIL_HOST_USER
    send_mail(subject, message, from_email, [doctor.email])
    
class Appointment(models.Model):
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='appointments')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    notes = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Confirmed', 'Confirmed')])