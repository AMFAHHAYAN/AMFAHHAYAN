import base64
from cryptography.fernet import Fernet
from django.conf import settings
from rest_framework import serializers
from django.contrib.auth.hashers import make_password, check_password
from .models import *

class EncryptionMixin:
    @staticmethod
    def generate_key():
        return Fernet.generate_key()

    @classmethod
    def encrypt_field(cls, value):
        if not hasattr(settings, 'ENCRYPTION_KEY'):
            raise ValueError("Encryption key not set in settings")
        
        f = Fernet(settings.ENCRYPTION_KEY)
        return f.encrypt(str(value).encode()).decode()

    @classmethod
    def decrypt_field(cls, encrypted_value):
        if not hasattr(settings, 'ENCRYPTION_KEY'):
            raise ValueError("Encryption key not set in settings")
        
        f = Fernet(settings.ENCRYPTION_KEY)
        return f.decrypt(encrypted_value.encode()).decode()

class UserSerializer(serializers.ModelSerializer, EncryptionMixin):
    class Meta:
        model = User
        fields = ('fullname', 'email', 'date_of_birth', 'phone', 'address')
    
    def to_representation(self, instance):
        ret = super().to_representation(instance)
        # Decrypt sensitive fields
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if ret.get(field):
                ret[field] = self.decrypt_field(ret[field])
        return ret

class RegisterSerializer(serializers.ModelSerializer, EncryptionMixin):
    password = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = '__all__'
        
    def create(self, validated_data):
        # Check if email already exists
        email = validated_data.get('email')
        if User.objects.filter(email=email).exists():
            raise serializers.ValidationError({"email": "This email is already registered."})
        
        # Encrypt sensitive fields
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if field in validated_data:
                validated_data[field] = self.encrypt_field(validated_data[field])
        
        # Hash password
        password = validated_data.pop('password')
        validated_data['password'] = make_password(password)
        
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        # Encrypt sensitive fields
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if field in validated_data:
                validated_data[field] = self.encrypt_field(validated_data[field])
        
        # Handle password update
        password = validated_data.get('password', None)
        if password:
            validated_data['password'] = make_password(password)
        
        return super().update(instance, validated_data)

class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(max_length=100, write_only=True)

    def validate(self, data):
        from django.utils import timezone
        
        email = data.get('email')
        password = data.get('password')

        try:
            user = User.objects.get(email=email)
            
            # Check password
            if not check_password(password, user.password):
                raise serializers.ValidationError("Invalid credentials")
            
            # Update last login timestamp
            user.last_login = timezone.now()
            user.save()
            
            return data
        except User.DoesNotExist:
            raise serializers.ValidationError("User not found")


class DoctorSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = Doctor
        fields = '__all__'

    def create(self, validated_data):
        # The password will be hashed automatically in the model's save method
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # The password will be hashed automatically in the model's save method if it's provided
        return super().update(instance, validated_data)
    
class UserDocSerialzer(serializers.ModelSerializer):
    class Meta:
        model = Doctor
        fields = ['id', 'name', 'specialization', 'location', 'availability']
    
class DoctorLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(max_length=100, write_only=True)

    def validate(self, data):
        email = data.get('email')
        password = data.get('password')

        try:
            doctor = Doctor.objects.get(email=email)
            
            # Check password
            if not check_password(password, doctor.password):
                raise serializers.ValidationError("Invalid credentials")
            
            # Update last login timestamp (assuming you have a `last_login` field or use another mechanism)
            # doctor.last_login = timezone.now()
            # doctor.save()
            
            return data
        except Doctor.DoesNotExist:
            raise serializers.ValidationError("Doctor not found")

# Appointment serializer remains the same
class Appointemntserializer(serializers.ModelSerializer):
    patient = RegisterSerializer(read_only=True)  
    doctor = DoctorSerializer(read_only=True)  

    class Meta:
        model = Appointment
        fields = ['id', 'patient', 'doctor', 'date', 'time', 'notes', 'status']