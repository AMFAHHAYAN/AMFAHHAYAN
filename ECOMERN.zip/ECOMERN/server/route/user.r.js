import express from "express";
import {
    createUser,
    getAllProducts,
    getAllUsers,
    login
} from "../controller/user.c";
import { addToCart, deleteCart, getCart, removeAllQuantity, removeFromCart, } from "../controller/cart.c";
import { createOrder, getOrderData } from "../controller/order.c";
import { VerifyUserAndRole } from "../middleware/verifyUser";
const userRoutes = express.Router();

// Public routes
userRoutes.post("/register", createUser);
userRoutes.post("/login", login);
userRoutes.get("/products", getAllProducts);

userRoutes.post("/add-to-cart", VerifyUserAndRole(), addToCart);
userRoutes.patch("/dec-item", VerifyUserAndRole(), removeFromCart);
userRoutes.delete("/delete-item", VerifyUserAndRole(), removeAllQuantity);
userRoutes.get("/cart/:userId", VerifyUserAndRole(), getCart);
userRoutes.post("/order", VerifyUserAndRole(), createOrder);
userRoutes.delete("/delete-cart", VerifyUserAndRole(), deleteCart);

userRoutes.get("/users", VerifyUserAndRole("admin"), getAllUsers);
userRoutes.get("/orders/:userId",VerifyUserAndRole(), getOrderData)

export default userRoutes;
