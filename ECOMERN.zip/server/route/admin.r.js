import express from "express";
import { addProduct, deleteProduct, getProductById, getProductsByAdmin, updateProduct } from "../controller/admin/admin.c";
import { login } from "../controller/user.c";
import { uploadMiddleware } from "../helper/uploadfiles";
import { VerifyUserAndRole } from "../middleware/verify";

const adminRoutes = express.Router();

adminRoutes.post("/add-product/:userId", VerifyUserAndRole("admin"), uploadMiddleware, addProduct);
adminRoutes.get("/all-products", VerifyUserAndRole("user"), getProductsByAdmin);
adminRoutes.post("/admin-login", login);
adminRoutes.get("/product/:productId", VerifyUserAndRole("user"), getProductById);
adminRoutes.put('/update-product/:productId', VerifyUserAndRole("admin"), uploadMiddleware, updateProduct);
adminRoutes.delete("/delete-product/:productId", VerifyUserAndRole("admin"), deleteProduct)

export default adminRoutes;
