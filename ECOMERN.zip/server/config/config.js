import 'dotenv/config.js';

export const config ={
    DB :{
        HOST : process.env.MONGO_HOST,
        PORT : process.env.MONGO_PORT,
        DATABASE : process.env.MONGO_DATABASE,
    },
    PORT : process.env.PORT,
    
}