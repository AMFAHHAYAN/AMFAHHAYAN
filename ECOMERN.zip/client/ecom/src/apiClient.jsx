import axios from "axios";

// Replace 'YOUR_BASE_URL' with your actual base URL
const BASE_URL = process.env.REACT_APP_BASE_URL;

const apiClient = axios.create({
    baseURL: BASE_URL
});

export default apiClient;
